<?php echo $this->inc('header.php', ['title' => 'Youtube Downloader']); ?>
	<div class="well marginserchbox">
		<form class="" method="get" id="download" action="getvideo.php">
			
				<div class="input-group">
				  <input type="text" name="videoid" id="videoid" class="form-control input-lg" placeholder="YouTube Link or VideoID">
				  <span class="input-group-btn">
					<input class="btn btn-primary btn-lg" type="submit" name="type" id="type" value="Download" />
				  </span>
				</div><!-- /input-group -->
			
		<!-- @TODO: Prepend the base URI -->
		
		
		
		<div class="clearfix"></div>
		</form>
	</div>
<?php echo $this->inc('footer.php'); ?>
